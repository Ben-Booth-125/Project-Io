# Project Io — Map Lenses

The **lens system** is the set of data overlays the player toggles over the
canvases from the bottom overlay control strip
([`overlay.cpp`](../../src/ui/overlay.cpp), `draw_overlay_controls`). One lens is
active at a time — the active mode is a single `overlay_mode` enum value
([`ui_state.hpp`](../../src/ui/ui_state.hpp)); `overlay_mode::none` is the plain
canvas. Each lens has one distinct vector glyph in the strip
(see [ICONS.md](ICONS.md) § Map-lens glyphs) and re-skins or annotates the canvas
when active.

This document is the *design* authority for what each lens shows, which rung of
the [canvas zoom ladder](CANVASES.md) it applies to, and how its legend reads.
Glyph shapes live in [ICONS.md](ICONS.md); identity colours live in
[`presentation.hpp`](../../src/ui/presentation.hpp) (the `palette` namespace).

> **Status.** All strip lenses are built except where a section names a gating
> dependency. The **Lens & Legibility** batch (BL-013/052/019/017/009/018) settled
> the curated single-select strip, renamed Faction → **Country**, reworked the
> **Resource** lens to a flat contiguous-deposit fill, reworked **Scarcity** to a
> per-market shortfall field, and added the **Opportunity** (net-margin) and
> **Production** (intensity) lenses. The **Market** lens's per-catchment surface
> still waits on multi-market seeding (BL-036); **Supply** waits on Layer-5 route
> geometry. Identity colours live in `presentation.hpp`; the corporation-identity
> helper is `palette::corp_colour` (renamed from `faction_colour`, BL-052).

---

## Rung applicability

Which lenses are meaningful on each rung of the ladder. "—" = no representation
intended; "✓" = built and active; "(later)" = a representation is specified here
but its build is gated on a dependency (named in the lens section).

The strip presents a **curated subset** in this order (BL-013): **Corporation →
Country → Resource → Market → Population → Opportunity → Production → Scarcity**.
Supply is off the strip (Layer-5, reached by keyboard lens-cycle). The default
active lens at campaign start is **Corporation**; the strip is single-select with a
null state (re-selecting the active lens clears to plain terrain).

The per-rung representation of every strip lens (the BL-012 sweep). "—" = no
representation intended; "✓" = built and active; "(later)" = specified but gated on
a dependency (named in the lens section).

| Lens | Solar | Circumplanetary | Planetary |
|---|---|---|---|
| Supply *(off strip)* | (later) inter-body route lines | (later) per-body throughput badge | (later) per-tile route + stockpile |
| **Corporation** | — | — | **✓ tile tint + player border** |
| **Country** | — | — | **✓ tile tint + owner borders** |
| **Resource** | — | — | **✓ contiguous-deposit flat fill + key** |
| **Market** | — | ✓ per-body price strip | ✓ per-body price wash |
| **Population** | — | — | **✓ habitability tint + gradient key** |
| **Opportunity** | — | — | **✓ best-building net-margin tint + key** |
| **Production** | — | (later) per-body output-throughput badge | **✓ production-intensity tint + key** |
| **Scarcity** | — | (later) per-body shortfall badge | **✓ per-market shortfall blocks + key** |

**BL-012 per-lens rung notes.** Corporation, Country, Resource, Population, and
Opportunity are **Planetary-only** — their unit of meaning (a tile, a building, a
deposit, a margin) is sub-body and has no coherent inter-body surface, and nations
are sub-body political units. Market and Supply are the genuinely multi-rung lenses
(prices per body-market; logistics span the ladder). Production and Scarcity are
Planetary today but each has a natural **Circumplanetary per-body badge** owed
(total output / aggregate shortfall for the anchor body) — additive passes guarded
behind the same `overlay_mode`, not changing the Planetary behaviour. None propagate
to the Solar rung in the prototype.

**Resource** is **built** (2026-06-16): unlike Supply and Market it had **no data
dependency** (tile `resource_deposit` is already generated), so it landed directly as a
Planetary render pass. See its section for the full spec.

Interaction notes shared by all lenses: lenses are **Planetary-first** in this
prototype, single-select (one `overlay_mode` at a time), and do not yet propagate
to the minimap. Selecting the already-active lens clears back to
`overlay_mode::none` (`toggle_overlay`). Coarser Solar/Circumplanetary
representations, where specified, are additive render passes guarded behind the
same `overlay_mode` — they do not change the Planetary behaviour.

---

## Corporation lens

**Intent.** Read the map as a *corporate landscape*: where corporations operate,
who owns what, and how the player's footprint sits against rivals. National
territory is the Faction lens's job — this lens is about **corporate-owned tiles**
first; nation context is deliberately absent.

**Ownership definition (settled).** A *corporate-owned tile* is any tile on which
a corporation holds a building. The mapping is derived at draw time from
`w.corporations[].assets` → `building_component.tile` (a building id resolves to
its tile). **There is no influence radius and no nation-domination heuristic in
this iteration** — only the literal building tile counts as owned. A tile with no
corporate building is *unowned*.

**Rung.** Planetary only. No Solar or Circumplanetary representation — the render
pass is guarded entirely behind `overlay_mode::corporation` in
[`body_surface_canvas.cpp`](../../src/ui/body_surface_canvas.cpp) and changes
nothing on the other two canvases.

**Colour.**
- **Owned tiles** are tinted their owning corporation's identity colour (a direct
  replacement of the terrain hue, matching the Faction lens's tint convention).
- The **player corporation** (`w.player_entity`) uses
  `presentation::faction_colour(0)` for its tile fill and additionally gets a thin
  border in `palette::selection` (white) so the player's holdings contrast against
  any rival fill colour at a glance.
- **Rival corporations** use the per-corp hashed faction slot already used for the
  building markers (a multiplicative hash kept off slot 0 so a rival never
  collides with the player's colour).
- **Unowned tiles** render in their plain terrain colour with **no tint** — there
  is no nation underlay in this lens.

**Glyph.** A filled square with a centred inner dot — a "seal" silhouette
(`icons::corporation`; see [ICONS.md](ICONS.md)). Distinct from the
extraction-site filled diamond, the processing-facility plain filled square, and
the port/unit filled triangle.

**Legend.** As with the other lenses today, the active lens is named only by the
strip glyph highlight and its hover tooltip (`overlay_mode_name` →
"Corporation ownership"); no on-canvas colour key yet. A per-corp colour key is a
follow-up shared with the Faction lens.

---

## Country lens

*(Renamed from "Faction" — BL-052. The lens shows **national** territory, so its
name is Country; `overlay_mode::country`, glyph `icons::country`. `"faction"`
remains a legacy alias in the verify-script name parser.)*

**Intent.** Read the map as a *political landscape*: which nation holds which
tile, and where the borders between them fall. This is the national counterpart
to the Corporation lens — territory, not corporate holdings.

**Ownership definition.** A tile's owner is its nation entity id, derived from the
`world` tile→nation ownership map (stored off-tile so the nation and tile-tuning
groups stay disjoint; see [NATION_GENERATION.md](../generation/NATION_GENERATION.md)).
Unclaimed tiles have no owner.

**Rung.** Planetary only. No Solar or Circumplanetary representation is intended:
nations are sub-body political units and have no coherent expression on the
inter-body rungs. The render pass is guarded behind `overlay_mode::country` in
[`body_surface_canvas.cpp`](../../src/ui/body_surface_canvas.cpp).

**Colour.**
- **Claimed tiles** are tinted their owning nation's identity colour
  (`palette::nation_colour`, keyed by nation entity id), a direct replacement of
  the terrain hue.
- **Borders:** a dark stroke is drawn on every hex edge shared with a neighbour of
  a *different* owner — including the claimed/unclaimed boundary — so contiguous
  territory reads as a filled region with a hard outline.
- **Unclaimed tiles** keep their plain terrain hue with no tint.

**Glyph.** A downward-pointing shield silhouette with a dark outline
(`icons::country`). Distinct from the corporation seal-square and the resource
strata.

**Legend.** Named by the strip glyph highlight and its hover tooltip
(`overlay_mode_name` → "Countries"); no on-canvas colour key yet. A
per-nation colour key is a follow-up shared with the Corporation lens (both want
the same identity-swatch list).

**Interaction notes.** Planetary-only, single-select. Borders are recomputed at
draw time from the neighbour ownership comparison; no border data is persisted.

## Supply lens *(target spec — gated on Layer 5 route geometry)*

**Intent.** Read the map as a *logistics network*: where goods move, along which
routes, and where throughput concentrates. The economic counterpart to Faction's
political read.

**Rung applicability.** Supply is the one lens with a meaningful representation on
*every* rung, because logistics span the zoom ladder:
- **Solar** — **inter-body route lines** between bodies that trade, weighted by
  throughput (line thickness/opacity).
- **Circumplanetary** — a **per-body throughput badge** summarising goods in/out
  for the focused body.
- **Planetary** — **per-tile** route segments and the producing/consuming tile's
  stockpile state.

**Colour.** Route lines and badges use a single neutral logistics hue
(`palette` entry, not per-faction) modulated by throughput; the lens is about flow
volume, not ownership. Tiles are not tinted — supply annotates, it does not
re-skin terrain.

**Glyph.** Two parallel horizontal lines — a route/convoy shorthand
(`icons::supply`). Distinct from the market vertical bars.

**Legend.** Strip glyph highlight + tooltip ("Supply routes"). A throughput
scale-key (line weight → goods/tick) is part of the build when routes render.

**Interaction notes.** Propagates across all three rungs (the exception to the
Planetary-first default). **Gated on Layer 5**: no convoy/route geometry is
generated yet, so nothing renders today. No interim Planetary-only stub is built —
the lens waits for its data.

## Market lens *(built 2026-06-16 — price resolution landed in v0.0.4)*

**Intent.** Read the map as a *price surface*: where a good is dear or cheap, and
how scarcity varies across markets. The complement to Supply — Supply shows flow,
Market shows the prices that drive it.

**Rung applicability.**
- **Solar** — none; prices are per-body-market and have no inter-body surface.
- **Circumplanetary** — a **per-body price strip** for the anchor body's market (a
  compact good→price list, the selected good highlighted).
- **Planetary** — a **body-wide price wash** for the player-selected good (dear =
  warm, cheap = cool). Markets are per-**body** (`market_component`), not per-tile, so
  the tint is uniform across the body — a property of the body's market, not of each
  tile.

**Colour.** A diverging warm↔cool gradient keyed to **price relative to the good's
own base (floor) price** (`price / base_price`); neutral mid-tone at the floor ratio
1.0, trending cool below and warm above, across the market's `[0.25×, 4×]` clamp band.
*(Refinement from the original "relative to the body mean": a basket mean across
resources of very different base prices is not meaningful — the per-good floor ratio is
the scarcity signal.)* As with Resource, the player picks which good the surface shows
(a good selector shared with the Resource lens's resource picker — one `lens_resource`).

**Glyph.** Three ascending bars — a price-chart silhouette (`icons::market`).
Distinct from the supply horizontal pair and the resource horizontal strata
(market bars are vertical and outlined).

**Legend.** Strip glyph highlight + tooltip ("Market prices") plus a diverging
gradient key (cheap↔dear) and the selected good's name when the per-tile surface
is active.

**Interaction notes.** Single-select. Price resolution landed in v0.0.4, so the lens
is built: the Circumplanetary strip and the Planetary wash share the resolved
`market_component.price`.

**Implemented 2026-06-16** (Market lens render Brief; design confirmed in the batch-close Q&A).
Planetary wash in `body_surface_canvas.cpp` (`diverging_colour`, composited over terrain at ~0.55
alpha); the per-body strip in **`circumplanetary_canvas.cpp`** — the Circumplanetary rung, *not*
`solar_system_canvas.cpp` as the Session-2 handoff's file list said (Solar has no market surface).
The good-selector is the shared combo from the Resource lens (`overlay.cpp`, bound to
`ui_state.lens_resource`). On-canvas keys/strip are inset past the nav rail (`nav_pane_width`) and
vertically centred. Verified by `scripts/verify/market_lens.lua`, which runs `verify.econ_step(12)`
to diverge prices from base before capture (and a new `verify.show_panel("economy", false)` hook to
clear the panel `econ_step` opens), against blessed goldens.

**Toward per-tile variation.** The wash is body-wide because the present world seeds **one market
per body**. The data model now supports **multiple tile-centred markets per body** — each market
carries a `centre_tile`, and a tile clears against the nearest centre's market (its *catchment*,
`market_for_tile` in `src/world/market_clearing.cpp`); landed 2026-06-16. When generation seeds
genuinely multiple centres (from capitals / population centres — owed, follows the population
layer, OPENS § Trade), this lens should tint **each market's catchment** rather than the whole
body, regaining a spatial per-market surface.

## Per-lens selection validity & routing (settled 2026-06-15, [F4])

The active lens does not only re-skin the canvas — it also **defines what the pointer resolves
to**. Each lens answers "what is the meaningful target under this pointer?" differently, so the
same position resolves to a different entity (and routes to a different ledger) per lens. The
Selection element walks the kind stack (SELECTION.md) and returns the first entity this lens calls
valid:

| Lens | Valid target under the pointer | Routes selection to |
|---|---|---|
| **none** | the lowest drawn entity (marker, else tile) | Tile Ledger |
| **Corporation** | the **owning corporation** of the tile/building | Balance Ledger |
| **Country** | the **owning nation** of the tile | Nation ledger |
| **Resource** | the tile's **deposit** profile | Tile Ledger (deposit detail) |
| **Market** | the body's **market** / the listing under the pointer | Market Ledger |
| **Opportunity** | the tile (and its best-building margin breakdown) | Tile Ledger |
| **Production** | the producing **building** under the pointer | Balance Ledger |
| **Scarcity** | the tile's **market** (the catchment under the pointer) | Market Ledger |
| **Supply** *(Layer 5)* | the **route segment / stockpile** under the pointer | (Supply surface) |

A lens skips kinds it does not validate: under the Corporation lens a hovered *building* resolves
*through* to its owning corporation, not to the building, because the corporation is the lens's
unit of meaning. Under no lens that same building resolves to itself. This is the per-lens
*validity* function the resolution rule consumes; the gating on data/geometry per lens (Market,
Supply) applies here too — a lens whose data does not yet exist contributes no valid target.

## Resource lens *(settled — next to build; no data dependency)*

**Intent.** Read the map as a *deposit-density surface*: where the body's mineral
and material wealth concentrates, so the player can site extraction before any
economy exists. This is the lens that pays off *now* — it needs no simulation,
only the tile generation already in place.

**Data definition (settled).** Every tile carries a `resource_deposit` profile
from generation (see [TILES.md](../economy/TILES.md) and
[TILE_GENERATION.md](../generation/TILE_GENERATION.md)). The lens reads that
profile directly at draw time; **no new data is generated**.

**Single mode — flat contiguous fill (settled, BL-019).** The lens is **always
single-resource** (no highest-value mode, no Single toggle): the player picks a
good from the shared selector and the lens fills the **whole contiguous deposit**
of that good as a **flat, uniform colour** — the *shape* of the deposit, not a
magnitude gradient. Every tile carrying any of the resource (deposit > 0) takes the
resource's identity colour at a fixed opacity (composited over terrain); a tile
without it keeps its terrain hue. Intensity lives in tile detail, not the lens. A
deposit is the 8-connected (diagonals included) blob of tiles with the good;
because the fill is uniform, the per-tile threshold is visually identical to a
flood-fill grouping, so no flood-fill pass is built.

**Rung.** Planetary only — deposits are per-tile and have no inter-body surface.
The render pass is guarded behind `overlay_mode::resource` in
[`body_surface_canvas.cpp`](../../src/ui/body_surface_canvas.cpp), matching the
Corporation/Faction pattern.

**Colour.** Resource identity colours from
[`presentation.hpp`](../../src/ui/presentation.hpp) (`presentation_of(res).colour`),
the same source the resource *pip* uses — so a tile's lens tint matches its pip.
Opacity carries magnitude; hue carries identity. No per-faction colours are
involved.

**Glyph.** Three stacked horizontal strata, widening and deepening in opacity
top-to-bottom — a gradient / deposit-density motif (`icons::resource`, the
`ImU32`-colour overload). Distinct from the supply horizontal *pair* (thin,
full-width, equal), the market *vertical* bars, the faction shield, and the
corporation seal-square; and distinct from the resource *pip* diamond (the
`resource_type` overload) it shares a name with.

**Legend.** Strip glyph highlight + tooltip ("Resource deposits"), plus an
on-canvas key: the selected resource's identity swatch + name and the note
"filled = deposit present". Flat, not a gradient — the lens shows deposit *shape*.

**Interaction notes.** Planetary-only, single-select. The resource selector is the
shared combo in the control strip (form shared with the Market and Scarcity
selectors, bound to `ui_state.lens_resource`). No new data, no tick dependency.

**Implemented 2026-06-17** (Lens & Legibility batch, BL-019). `overlay_mode::resource`
Planetary pass in `body_surface_canvas.cpp`: a tile with `resource_deposit[sel] > 0` is
composited toward `presentation_of(sel).colour` at a fixed 0.8 (uniform flat fill); other tiles
keep terrain. The highest-value mode and the `resource_lens_single` toggle were removed (the
lens is always single). The on-canvas key sits at the left edge, vertically centred, inset past
the nav rail. Verified by `scripts/verify/resource_lens.lua` against blessed goldens
(deterministic after the draw-order fix).

## Population lens *(built 2026-06-16 — no data dependency)*

**Intent.** Read the map as a *liveability surface*: where land is hospitable, so the player can
weigh siting and (later) population pressure. The complement to Resource's material read.

**Data definition (settled).** Every tile carries a `habitability` value in `[0, 1]` from
generation (`tile_component.habitability`). The lens reads it directly at draw time; **no new data
is generated**. Population *density* (people per tile) is **deferred** — population centres are not
yet generated — so this lens reads **habitability only** for now; the density half folds in when the
population layer lands (§ Workforce / § Infrastructure Briefs).

**Rung.** Planetary only — habitability is per-tile and has no inter-body surface. Guarded behind
`overlay_mode::population` in [`body_surface_canvas.cpp`](../../src/ui/body_surface_canvas.cpp).

**Colour.** A sequential dark→liveable-green gradient: a tile's terrain hue is composited toward a
"liveable" green (`IM_COL32(80, 200, 110)`) at opacity `0.15 + 0.7·habitability` (`lerp_colour`), so
hospitable land reads bright and barren land barely tints. Sequential (not diverging) — habitability
has a single good direction. No per-faction colours.

**Glyph.** A small figure — round head over a tapered torso (`icons::population`); reads as
"people / habitability", distinct from the other lens glyphs.

**Legend.** A low→high habitability gradient bar, left edge, vertically centred, inset past the nav
rail (the Resource/Market key placement). Tooltip "Habitability".

**Interaction notes.** Planetary-only, single-select, no selector (the whole-body habitability
surface needs no resource pick). Verified by `scripts/verify/population_lens.lua` against blessed
goldens. **Toward population density (future):** when population centres generate, this lens should
gain a density read (a second mode or a blended signal) — owed with the population layer.

## Opportunity lens *(built 2026-06-17 — BL-017)*

**Intent.** Read the map as a *siting surface*: where could value be made? Each tile
shows the estimated **net margin of the best valid building on its terrain** — the
counterpart to Population's liveability read. Paired with Population on the strip
(both replace the former Habitability main-lens).

**Data definition (settled).** For each tile, over the building types valid on its
terrain (`placement_rules::can_place`): **extraction** — the best single deposit's
`base_rate × richness × price − maintenance − wage`; **processing** — the best
recipe's `base_rate × (Σ outputs×price − Σ inputs×price) − maintenance − wage`. The
margin is the max over candidates, evaluated **ignoring what is currently built and
ignoring logistics** (it is potential, not actual). Prices come from the tile's
market (`market_for_tile`); upkeep from the recipe registry. No new data.

**Rung.** Planetary only. Guarded behind `overlay_mode::opportunity`.

**Colour.** A **diverging** surface normalised against the body's largest absolute
margin: profit composites toward green (`IM_COL32(110,200,120)`), loss toward red
(`IM_COL32(216,100,96)`), at `0.75 · |margin|/max`. Tiles with no valid building keep
terrain.

**Glyph.** An open circle with an inner "+" (`icons::opportunity`) — a potential-gain
motif.

**Legend.** Strip glyph + tooltip ("Opportunity (net margin)") + an on-canvas
loss→profit diverging key.

**Interaction notes.** Planetary-only, single-select; the script ticks the economy
first so prices have resolved. Verified by `scripts/verify/opportunity_lens.lua`.
Owed follow-on: the margin formula is a first-cut estimate (single workforce, no
contention); refine when the build-cost amortisation model lands.

## Production lens *(built 2026-06-17 — BL-009)*

**Intent.** Read the map as a *production-intensity surface*: where value is actually
being made right now. Complements Opportunity (potential) with the realised output.

**Data definition (settled).** Per producing tile, intensity = **Σ(output qty ×
resolved price)** across the building's outputs this tick, read from the
`economy_report` (`output_quantity`) and the tile's market prices; a processor's
total output is split across its recipe's products by their batch proportions.
Idle / exhausted / unbuilt tiles produce nothing → no entry → cold.

**Rung.** Planetary today; a Circumplanetary per-body output badge is owed (rung
table). Guarded behind `overlay_mode::production`.

**Colour.** Each producing tile's value is taken **relative to the body's
producing-tile geometric mean** and run through the diverging warm↔cool ramp
(`diverging_colour`, the same band the Market wash uses): above the mean reads warm,
below cool, composited at 0.6 over terrain. So contrast is meaningful across bodies
of very different absolute output; a body of similar producers reads near-neutral
(honest — there is little intensity spread to show).

**Glyph.** A filled upward triangle over a baseline (`icons::production`) — output
rising.

**Legend.** Strip glyph + tooltip ("Production intensity") + an on-canvas low→high
diverging key.

**Interaction notes.** Planetary-only, single-select; the script ticks the economy
so buildings produce and the report populates before capture. Verified by
`scripts/verify/production_lens.lua`.

## Scarcity lens *(built 2026-06-16 — no data dependency)*

**Intent.** The inverse of the Resource lens: read the map as an *absence surface* — where a chosen
good is **scarce or absent**, so the player sees gaps rather than concentrations. Answers "where is
there *no* iron?" directly, which the density lens only shows by omission.

**Data definition (settled, BL-018).** Reads **market supply shortfall**, not tile deposits:
`shortfall = max(0, market.demand[sel] − market.supply[sel])` — how much demand outran supply for
the selected good last tick, independent of price. **Single-resource only** (scarcity *of what?*);
the good is the shared `ui_state.lens_resource` (same combo as Resource and Market). Reads the
existing `market_component` arrays — no new data; needs the economy to have ticked so supply/demand
are populated.

**Rung.** Planetary only. Guarded behind `overlay_mode::scarcity` in `body_surface_canvas.cpp`.

**Colour — chunky per-market blocks.** The lens is a **market-level field**, not a per-tile one:
every tile in a market's catchment (via `market_for_tile`) reads as **one solid block** tinted by
that market's shortfall, normalised across the body's markets (the body-max shortfall in a pre-pass).
A tile is composited toward a hot hue (`IM_COL32(220, 70, 55)`) at opacity `0.6 · scarcity`, so a
met market keeps terrain and a short one reads hot. With one market per body (the present generation)
the whole body reads as a single block — honest to the market structure (the catchment is the unit);
it gains spatial variation once multiple centres are seeded (BL-036).

**Glyph.** A hollow downward-pointing triangle (`icons::scarcity`) — an "empty / depleted" motif,
the inverse of the filled resource pip.

**Legend.** An abundant→scarce gradient bar plus the selected resource's name and identity swatch,
same placement as the others. Tooltip "Resource scarcity". The resource selector appears in the
control strip when the lens is active (shared form with Resource/Market).

**Interaction notes.** Planetary-only, single-select. The script runs `verify.econ_step(12)` so
market supply/demand populate before capture. Verified by `scripts/verify/scarcity_lens.lua`
against blessed goldens (iron and steel variants prove the selector re-skins the surface).

**Implemented 2026-06-17** (Lens & Legibility batch, BL-018). Reworked from the prior deposit-based
per-tile heatmap to per-market shortfall blocks: a pre-pass collects each body market's
`max(0, demand−supply)` of the selected good and the body-max; the fill pass maps each tile to its
market (`market_for_tile`) and composites the hot hue by the normalised shortfall. The on-canvas key
reads "Market scarcity" (met → scarce).
