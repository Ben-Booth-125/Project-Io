#include "market_clearing.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <vector>

namespace {

// --- Price resolution constants (TODO § Trade, settled 2026-06-15) ---------
// Price is anchored to the rarity-derived base_price and pushed by this tick's
// supply/demand ratio. A damped (sqrt) elasticity keeps swings readable; the
// move is clamped to a band around base and eased across ticks so a single tick's
// imbalance cannot snap the price.
constexpr float price_floor_mult = 0.25f; ///< Lowest a price may fall: 0.25× base.
constexpr float price_ceil_mult  = 4.0f;  ///< Highest a price may rise: 4× base.
constexpr float price_smoothing  = 0.5f;  ///< EMA factor toward the tick's target price.

/// Resolve one resource's price for a market this tick. The target is
/// `base × sqrt(demand/supply)` (damped elasticity), clamped to the band and
/// reached by an exponential moving average from the prior price. Untraded
/// resources (`base <= 0`) keep their prior price.
float resolve_price(float prior, float base, float supply, float demand)
{
    if (base <= 0.0f)
        return prior; // never traded here — leave it (stays 0)

    float target;
    if (supply <= 0.0f && demand <= 0.0f)
        target = base; // no signal this tick — pull gently back toward base
    else if (supply <= 0.0f)
        target = base * price_ceil_mult; // demand with no supply — top of the band
    else
        target = base * std::sqrt(demand / supply); // demand 0 → target 0 → floored below

    const float lo = base * price_floor_mult;
    const float hi = base * price_ceil_mult;
    target = std::clamp(target, lo, hi);

    const float next = prior + price_smoothing * (target - prior);
    return std::clamp(next, lo, hi);
}

/// One side of an order-book entry for a single (market, resource) pair.
struct ob_sell_entry
{
    entity_id corp;
    float     qty;
    float     floor_price; ///< Minimum acceptable unit price (0 for auto-surplus).
};

struct ob_buy_entry
{
    entity_id corp;
    float     qty;
    float     max_price;        ///< Maximum acceptable unit price (999 for auto-demand).
    entity_id preferred_seller; ///< Optional counterparty hint; null_entity = no preference.
};

/// One matched trade: both parties, quantities, and clearing price.
struct matched_trade
{
    entity_id seller;
    entity_id buyer;
    entity_id market;
    std::size_t r;
    float     qty;
    float     price; ///< Clearing price = seller's floor_price (ask).
};

/// Markets present on each body, in ascending market-id order (deterministic).
std::unordered_map<entity_id, std::vector<entity_id>> markets_by_body(const world& w)
{
    std::unordered_map<entity_id, std::vector<entity_id>> map;
    map.reserve(w.markets.size());
    for (const auto& [mid, mc] : w.markets)
        map[mc.body].push_back(mid);
    for (auto& [body, ids] : map)
        std::sort(ids.begin(), ids.end());
    return map;
}

/// Pick, from a body's markets, the one whose centre tile is nearest `tile`.
/// One market → that market (anchored or not). Several → the nearest anchored
/// centre by squared grid distance (ties → lowest id); an unanchored market is a
/// candidate only if every market on the body is unanchored, in which case the
/// lowest id wins.
entity_id nearest_market(const world& w, const std::vector<entity_id>& body_markets,
                         const tile_component& tile)
{
    if (body_markets.empty())
        return null_entity;
    if (body_markets.size() == 1)
        return body_markets.front();

    entity_id best      = null_entity;
    long long best_dist = 0;
    for (const entity_id mid : body_markets)
    {
        const entity_id centre = w.markets.at(mid).centre_tile;
        const auto cit = w.tiles.find(centre);
        if (cit == w.tiles.end())
            continue; // unanchored — skip while an anchored market exists
        const long long dx = cit->second.grid_x - tile.grid_x;
        const long long dy = cit->second.grid_y - tile.grid_y;
        const long long d  = dx * dx + dy * dy;
        if (best == null_entity || d < best_dist)
        {
            best      = mid;
            best_dist = d;
        }
    }
    return best != null_entity ? best : body_markets.front(); // all unanchored
}

/// Input reservation a corporation needs to keep on a body to feed a full run of
/// its own processors next tick — so it sells only the genuine surplus.
std::array<float, resource_count> processor_reservation(
    const world& w, const recipe_registry& reg, entity_id corp, entity_id body)
{
    std::array<float, resource_count> reserve = {};
    const corporation_component& cc = w.corporations.at(corp);
    const float batches_full_per_workforce =
        reg.economics(building_type::processing_facility).base_rate;

    for (const entity_id bid : cc.assets)
    {
        const auto bit = w.buildings.find(bid);
        if (bit == w.buildings.end())
            continue;
        const building_component& b = bit->second;
        if (b.type != building_type::processing_facility)
            continue;

        const auto tit = w.tiles.find(b.tile);
        if (tit == w.tiles.end() || tit->second.body != body)
            continue;

        const recipe* rcp = reg.get_recipe(b.recipe);
        if (!rcp)
            continue;

        const float batches = batches_full_per_workforce * b.workforce_assigned;
        for (std::size_t r = 0; r < resource_count; ++r)
            reserve[r] += rcp->inputs[r] * batches;
    }
    return reserve;
}

/// A corporation's representative tile on a body: the tile of its lowest-id
/// building there. Used to route the corp's body-aggregate supply/demand to a
/// market when the body carries several. `null_entity` if the corp holds nothing
/// on the body.
entity_id representative_tile(const world& w, entity_id corp, entity_id body)
{
    const auto cit = w.corporations.find(corp);
    if (cit == w.corporations.end())
        return null_entity;

    entity_id best_building = null_entity;
    entity_id best_tile     = null_entity;
    for (const entity_id bid : cit->second.assets)
    {
        const auto bit = w.buildings.find(bid);
        if (bit == w.buildings.end())
            continue;
        const auto tit = w.tiles.find(bit->second.tile);
        if (tit == w.tiles.end() || tit->second.body != body)
            continue;
        if (best_building == null_entity || bid < best_building)
        {
            best_building = bid;
            best_tile     = bit->second.tile;
        }
    }
    return best_tile;
}

/// Route a corp's body-aggregate clearing to one market: the market nearest the
/// corp's representative tile on the body (one market → that market; no holdings
/// there → the body's lowest-id market). `null_entity` if the body has no market.
entity_id market_for_corp_on_body(
    const world& w, const std::unordered_map<entity_id, std::vector<entity_id>>& by_body,
    entity_id corp, entity_id body)
{
    const auto it = by_body.find(body);
    if (it == by_body.end() || it->second.empty())
        return null_entity;
    if (it->second.size() == 1)
        return it->second.front();

    const entity_id rep = representative_tile(w, corp, body);
    const auto tit = w.tiles.find(rep);
    if (tit == w.tiles.end())
        return it->second.front();
    return nearest_market(w, it->second, tit->second);
}

} // namespace

entity_id market_for_tile(const world& w, entity_id tile)
{
    const auto tit = w.tiles.find(tile);
    if (tit == w.tiles.end())
        return null_entity;
    const auto by_body = markets_by_body(w);
    const auto it = by_body.find(tit->second.body);
    if (it == by_body.end())
        return null_entity;
    return nearest_market(w, it->second, tit->second);
}

std::unordered_map<entity_id, corp_cash_flow> clear_markets(
    world& w,
    const recipe_registry& reg,
    const economy_report& report,
    const std::vector<sell_order>& player_orders,
    const std::vector<buy_order>&  player_buy_orders)
{
    std::unordered_map<entity_id, corp_cash_flow> flows;
    const auto by_body = markets_by_body(w);

    for (auto& [mid, mc] : w.markets)
    {
        mc.supply.fill(0.0f);
        mc.demand.fill(0.0f);
    }

    // Inject nation-substrate background supply and demand into markets before the
    // order-book runs. Must come after the zero-reset above so substrate is additive
    // to the order-book quantities, not erased by it.
    inject_substrate_demand(w);

    // A (corp, body, resource) the player has a standing sell order for is under
    // manual control: the auto-surplus path yields it so the player's floor-priced
    // order governs the sale, not the greedy auto path.
    auto player_sell_controls = [&player_orders](entity_id corp, entity_id body, std::size_t r) {
        for (const sell_order& o : player_orders)
            if (o.corp == corp && o.body == body &&
                static_cast<std::size_t>(o.resource) == r && o.quantity > 0.0f)
                return true;
        return false;
    };

    // --- Separate auto-clearing entries from the explicit-order books ---
    //
    // Auto-surplus and auto-demand (processor shortfalls) always clear at the
    // reference price derived from supply/demand ratios — the market is a perfect
    // counterparty for these. Explicit player orders go through the order book and
    // also auto-clear at max(ref_price, floor) when no matching buyer exists, so
    // supply is always guaranteed to clear (prototype invariant).
    struct auto_sell_entry { entity_id corp; entity_id market; std::size_t r; float qty; };
    struct auto_buy_entry  { entity_id corp; entity_id market; std::size_t r; float qty; };
    std::vector<auto_sell_entry> auto_sells;
    std::vector<auto_buy_entry>  auto_buys;

    // Explicit priced player orders: supply/demand recorded into mc AND into order books.
    std::unordered_map<entity_id, std::unordered_map<std::size_t, std::vector<ob_sell_entry>>> sell_books;
    std::unordered_map<entity_id, std::unordered_map<std::size_t, std::vector<ob_buy_entry>>>  buy_books;

    // Auto-surplus: each corp's pool above its processor reservation.
    for (auto& [key, pool] : w.corp_body_pools)
    {
        const entity_id corp = key.first;
        const entity_id body = key.second;

        const entity_id mid = market_for_corp_on_body(w, by_body, corp, body);
        if (mid == null_entity)
            continue;
        if (w.corporations.find(corp) == w.corporations.end())
            continue;

        const market_component& mc = w.markets.at(mid);
        const auto reserve = processor_reservation(w, reg, corp, body);

        for (std::size_t r = 0; r < resource_count; ++r)
        {
            if (mc.base_price[r] <= 0.0f)
                continue;
            if (player_sell_controls(corp, body, r))
                continue;

            const float surplus = pool.quantities[r] - reserve[r];
            if (surplus <= 0.0f)
                continue;

            w.markets.at(mid).supply[r] += surplus;
            auto_sells.push_back({corp, mid, r, surplus});
        }
    }

    // Player sell orders: into mc.supply and the explicit sell book.
    for (const sell_order& order : player_orders)
    {
        if (order.quantity <= 0.0f)
            continue;
        const entity_id mid = market_for_corp_on_body(w, by_body, order.corp, order.body);
        if (mid == null_entity)
            continue;
        const std::size_t r = static_cast<std::size_t>(order.resource);
        const auto pkit = w.corp_body_pools.find(std::make_pair(order.corp, order.body));
        if (pkit == w.corp_body_pools.end())
            continue;
        const float available = std::min(order.quantity, pkit->second.quantities[r]);
        if (available <= 0.0f)
            continue;
        w.markets.at(mid).supply[r] += available;
        sell_books[mid][r].push_back({order.corp, available, order.floor_price});
    }

    // Auto-demand: processor input shortfalls from the economy report.
    for (const auto& [key, bought] : report.purchases)
    {
        const entity_id corp = key.first;
        const entity_id body = key.second;

        const entity_id mid = market_for_corp_on_body(w, by_body, corp, body);
        if (mid == null_entity)
            continue;

        for (std::size_t r = 0; r < resource_count; ++r)
        {
            const float qty = bought[r];
            if (qty <= 0.0f)
                continue;
            w.markets.at(mid).demand[r] += qty;
            auto_buys.push_back({corp, mid, r, qty});
        }
    }

    // Player buy orders: into mc.demand and the explicit buy book.
    for (const buy_order& order : player_buy_orders)
    {
        if (order.quantity <= 0.0f)
            continue;
        const entity_id mid = market_for_corp_on_body(w, by_body, order.corp, order.body);
        if (mid == null_entity)
            continue;
        const std::size_t r = static_cast<std::size_t>(order.resource);
        w.markets.at(mid).demand[r] += order.quantity;
        buy_books[mid][r].push_back({order.corp, order.quantity, order.max_price,
                                     order.preferred_seller});
    }

    // --- Reference prices from accumulated supply/demand ---
    // Computed once, before any clearing, so all income/expenditure uses the same price.
    std::unordered_map<entity_id, std::array<float, resource_count>> ref_price;
    for (const auto& [mid, mc] : w.markets)
    {
        ref_price[mid] = {};
        for (std::size_t r = 0; r < resource_count; ++r)
            ref_price[mid][r] = resolve_price(mc.price[r], mc.base_price[r],
                                              mc.supply[r], mc.demand[r]);
    }

    // --- Auto-surplus clearing: income at ref_price, pool debited immediately ---
    for (const auto_sell_entry& se : auto_sells)
    {
        const entity_id body = w.markets.at(se.market).body;
        auto pkit = w.corp_body_pools.find(std::make_pair(se.corp, body));
        if (pkit != w.corp_body_pools.end())
            pkit->second.quantities[se.r] -= se.qty;
        flows[se.corp].income += se.qty * ref_price[se.market][se.r];
    }

    // --- Auto-demand clearing: expenditure at ref_price ---
    for (const auto_buy_entry& be : auto_buys)
        flows[be.corp].expenditure += be.qty * ref_price[be.market][be.r];

    // --- Explicit order-book matching (player sell vs player buy) ---
    // Provides preferred-seller routing and a VWAP price signal when priced orders
    // dominate. Unmatched player sell supply auto-clears below (market as buyer of
    // last resort at max(ref_price, floor)), so supply always clears.
    std::vector<matched_trade> trades;

    for (auto& [mid, sell_by_r] : sell_books)
    {
        for (auto& [r, sellers] : sell_by_r)
        {
            auto& buyers_map = buy_books[mid];
            auto  bit        = buyers_map.find(r);

            if (bit == buyers_map.end())
                continue; // no explicit buyers — handled by auto-clear below

            std::vector<ob_buy_entry>& buyers = bit->second;

            // Sort: cheapest seller first, then corp id for determinism.
            std::sort(sellers.begin(), sellers.end(),
                [](const ob_sell_entry& a, const ob_sell_entry& b) {
                    return a.floor_price != b.floor_price
                        ? a.floor_price < b.floor_price
                        : a.corp < b.corp;
                });

            // Sort: highest bidder first, then corp id for determinism.
            std::sort(buyers.begin(), buyers.end(),
                [](const ob_buy_entry& a, const ob_buy_entry& b) {
                    return a.max_price != b.max_price
                        ? a.max_price > b.max_price
                        : a.corp < b.corp;
                });

            // Working copies of remaining quantities so we can drain both sides.
            std::vector<float> sell_rem(sellers.size());
            std::vector<float> buy_rem(buyers.size());
            for (std::size_t i = 0; i < sellers.size(); ++i) sell_rem[i] = sellers[i].qty;
            for (std::size_t i = 0; i < buyers.size();  ++i) buy_rem[i]  = buyers[i].qty;

            // Match: highest-priority buyer draws from the cheapest compatible seller.
            for (std::size_t bi = 0; bi < buyers.size(); ++bi)
            {
                if (buy_rem[bi] <= 0.0f)
                    continue;

                const ob_buy_entry& buyer = buyers[bi];

                float cheapest_price = -1.0f;
                for (std::size_t si = 0; si < sellers.size(); ++si)
                {
                    if (sell_rem[si] <= 0.0f)
                        continue;
                    if (sellers[si].floor_price > buyer.max_price)
                        continue;
                    if (cheapest_price < 0.0f || sellers[si].floor_price < cheapest_price)
                        cheapest_price = sellers[si].floor_price;
                }
                if (cheapest_price < 0.0f)
                    continue;

                for (int pass = 0; pass <= 1 && buy_rem[bi] > 0.0f; ++pass)
                {
                    for (std::size_t si = 0; si < sellers.size() && buy_rem[bi] > 0.0f; ++si)
                    {
                        if (sell_rem[si] <= 0.0f)
                            continue;

                        const bool is_preferred =
                            buyer.preferred_seller != null_entity &&
                            sellers[si].corp == buyer.preferred_seller;

                        if (pass == 0 && !is_preferred)
                            continue;
                        if (pass == 1 && is_preferred)
                            continue;

                        const float ask = sellers[si].floor_price;
                        if (ask > buyer.max_price)
                            continue;

                        if (is_preferred && ask > cheapest_price * 1.10f)
                            continue;

                        const float fill = std::min(buy_rem[bi], sell_rem[si]);
                        sell_rem[si] -= fill;
                        buy_rem[bi]  -= fill;

                        trades.push_back({sellers[si].corp, buyer.corp, mid, r, fill, ask});
                    }
                }
            }
        }
    }

    // --- Debit pools and accrue cash flows for matched explicit trades ---
    for (const matched_trade& t : trades)
    {
        const entity_id body = w.markets.at(t.market).body;
        auto pkit = w.corp_body_pools.find(std::make_pair(t.seller, body));
        if (pkit != w.corp_body_pools.end())
            pkit->second.quantities[t.r] -= t.qty;
        flows[t.seller].income     += t.qty * t.price;
        flows[t.buyer].expenditure += t.qty * t.price;
    }

    // --- Auto-clear unmatched player sell supply ---
    // The market is a buyer of last resort at max(ref_price, floor). Aggregate matched
    // sell qty per (seller, market, r) from the explicit trades, then clear the rest.
    {
        std::map<std::tuple<entity_id, entity_id, std::size_t>, float> matched_sell;
        for (const matched_trade& t : trades)
            matched_sell[{t.seller, t.market, t.r}] += t.qty;

        for (const auto& [mid, sell_by_r] : sell_books)
        {
            const entity_id body = w.markets.at(mid).body;
            for (const auto& [r, sellers] : sell_by_r)
            {
                const float rp = ref_price[mid][r];
                for (const ob_sell_entry& se : sellers)
                {
                    const float already_matched =
                        [&]() -> float {
                            auto it = matched_sell.find({se.corp, mid, r});
                            return it != matched_sell.end() ? it->second : 0.0f;
                        }();
                    const float unmatched = se.qty - already_matched;
                    if (unmatched <= 0.0f)
                        continue;
                    const float clearing = std::max(rp, se.floor_price);
                    auto pkit = w.corp_body_pools.find(std::make_pair(se.corp, body));
                    if (pkit != w.corp_body_pools.end())
                        pkit->second.quantities[r] -= unmatched;
                    flows[se.corp].income += unmatched * clearing;
                }
            }
        }
    }

    // --- Price update: ref_price (pre-computed from supply/demand) ---
    // Explicit priced trades provide a VWAP signal; when they occurred, ease toward
    // the VWAP. Otherwise use the supply/demand reference price directly (it already
    // incorporates the EMA from resolve_price).
    {
        struct vwap_acc { float vol = 0.0f; float qty = 0.0f; };
        std::unordered_map<entity_id, std::array<vwap_acc, resource_count>> vwap;
        for (const matched_trade& t : trades)
        {
            vwap[t.market][t.r].vol += t.price * t.qty;
            vwap[t.market][t.r].qty += t.qty;
        }

        for (auto& [mid, mc] : w.markets)
        {
            for (std::size_t r = 0; r < resource_count; ++r)
            {
                const auto vit = vwap.find(mid);
                if (vit != vwap.end() && vit->second[r].qty > 0.0f)
                {
                    const float tick_vwap = vit->second[r].vol / vit->second[r].qty;
                    mc.price[r] = mc.price[r] + price_smoothing * (tick_vwap - mc.price[r]);
                }
                else
                {
                    mc.price[r] = ref_price[mid][r];
                }
            }
        }
    }

    return flows;
}
