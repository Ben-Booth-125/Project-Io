# Project Io — Claude Reference

Project Io is a near-future space-based 4X grand strategy game. The player controls a corporate entity competing through resource extraction, trade, and military conflict across an Earth-like solar system. The project is in prototype phase, solo-developed in C++ with Lua scripting.

Read the documents below before responding to any request. They are the authoritative source for all design and technical decisions.

---

## Documents

**`docs/CONCEPT.md`**
The player identity, core mechanics, and campaign design. Start here for questions about what the game is and how it should feel.

**`docs/SYSTEMS.md`**
Every game system, how they relate to one another, and which are load-bearing. Read this for questions about scope, system design, or how a feature fits into the whole.

**`docs/GLOSSARY.md`**
Canonical definitions for all project terms. Use these terms consistently. If a term is defined here, do not substitute alternatives.

**`docs/tech/TECH_FOUNDATIONS.md`**
All settled technical decisions: language, framework, architecture, tick model, data model, UI approach, and serialisation. Read this before writing any code or making any architectural suggestion. It also defines the prototype scope and what is explicitly excluded.

**`docs/development/ROADMAP.md`**
The milestone map from the current state to v0.1.0 (the finished prototype): the version sequence, the theme of each minor, and the v0.1.0 done-definition. Forward-facing and lean — it sits above the backlog and worklist, naming which theme each minor carries, not the individual items. Read this for questions about sequence, what comes when, or whether a feature belongs in the prototype's remaining arc.

**`docs/development/DEVELOPMENT_PRACTICES.md`**
Testing framework (Catch2), naming conventions, documentation standards, the per-milestone ImGui panel rule, the standing development constraints, the tone/approach guidance, and how to cut a release. Read this alongside TECH_FOUNDATIONS when working on implementation.

**`docs/development/DEVLOG.md`**
Running session log — chronological record of what was built each session and
in-session decisions. Consult when asked about prior work, open items, or why
a specific implementation choice was made.

**`docs/development/backlog.json`**, **`docs/development/BACKLOG.md`**, **`docs/development/REFINED.md`**, and **`docs/development/DELIVERY.md`**
The backlog and delivery system. **`backlog.json`** is the canonical **metadata index and design
prose store** — status (`designed` ✓ / `design-owed` ~), priority, difficulty, sequencing, file
scope, and the **`design` field** holding each item's prose. **`BACKLOG.md`** is a **legacy drain**:
it holds markdown bodies only for older items not yet migrated; when an item is edited or promoted,
its body moves to `backlog.json`'s `design` field and is replaced by a tombstone. New items get
**no** `BACKLOG.md` body. Authority time-slices: `backlog.json` while the item is open; the
subject's authority doc once the work lands. **`REFINED.md`** is the *active worklist*: a `designed`
item is **promoted** into file-scoped tasks when we act on it. **`DELIVERY.md`** is the method
authority — the Delivery lifecycle, design-state model, depth verbs, and worktree sub-agent model.
Read DELIVERY.md before promoting or executing backlog work.

**`docs/ui/CANVASES.md`**
Overview of the three primary canvases — Solar, Circumplanetary, and Planetary — arranged as a **zoom ladder** (descend by clicking a body in the primary, ascend by clicking the minimap). Covers the shared layout, selection/view state, and implementation approach. Per-canvas detail lives in `SOLAR.md`, `CIRCUMPLANETARY.md`, and `PLANETARY.md`; the minimap chrome and ladder navigation are in `MINIMAP.md`. Authoritative reference for Layer 2 and for later work that adds overlays to these canvases.

**`docs/ui/SELECTION.md`**
The Selection info element — a pinned, polymorphic panel showing detail of the current selection. Defines the three interaction states (Active / Focus / Selection) and the single-click-selects / double-click-navigates click-model change shared across all canvases. Read before any work on selection state, canvas click handling, or the shared per-entity content builders (which the Tile Ledger and the future hover card also use).

**`docs/ui/LAYOUT.md`**
Surface-level description of the application shell — how the screen regions (navigation pane, canvas area, time column, ledger windows) are arranged around the canvases. Read for questions about overall UI layout; CANVASES.md covers the canvas internals.

**`docs/ui/ICONS.md`**
The icon vocabulary — every hand-drawn vector glyph in the `ui::icons` namespace (`src/ui/icons.{hpp,cpp}`, the source of truth): building markers, resource pips, unit markers, nav-rail affordances, and the map-lens glyphs. Catalogues each glyph's shape, meaning, usage, and colour source, the shared `(dl, centre, r, colour)` contract, and the recipe for adding one. Read before adding or changing any on-canvas/strip glyph; identity *colours* live in `presentation.hpp`, not here.

**`docs/ui/LENSES.md`**
The map-lens system — the overlay modes (`overlay_mode` in `src/ui/ui_state.hpp`) selectable from the canvas control strip. The **Corporation** lens is fully settled (tile ownership tint, player vs. rival colours, Planetary-only); the **Supply / Market / Faction** sections currently record existing behaviour and the proposed **Resource** lens is a stub — completing them is a backlog item under BACKLOG § Canvas. Read before any work on overlay modes, lens rendering, or the lens icon vocabulary (which propagates to ICONS.md).

**`docs/economy/RESOURCES.md`**
The canonical resource list: all 23 resources organised into three tiers (raw → refined → product), their terrain affinity and body availability, the Era 0 / Era 1 split, and the seven-resource prototype subset. Read before any work involving resource types, tile deposits, or market goods.

**`docs/economy/PRODUCTION.md`**
All extraction and processing buildings: placement rules, valid terrain, output resources, and full recipe tables. Also covers the workforce scalar model, stockpile flow, and the Layer 3 prototype scope. Read before any work involving buildings, recipes, or production logic.

**`docs/economy/ERAS.md`**
The Era system — the formal phase structure of the game's industrial arc. Era 0 (Terrestrial) starts at the campaign epoch; Era 1 (Early Space) is unlocked by the Rocketry research + Launchpad + propellant gate. Read for questions about what is accessible when, and how the transition to space is structured.

**`docs/economy/TILES.md`**
Tile classification: the two-axis terrain model (composition × landform), resource deposit profiles per terrain type, ambient resource guarantee, and amenity tile concept. Read before any work involving terrain types, tile generation, or the `terrain_composition`/`terrain_landform` enums. Includes an implementation note recording that the two-axis split is now implemented.

**`docs/economy/POPULATION.md`**
Population centres, scale/agglomeration mechanics, land-use trade-offs, and habitability feedback. Deferred from the prototype but designed here so the data model positions correctly. Read for questions about workforce, habitability, or population demand.

**`docs/generation/GENERATION_STRATEGY.md`**
The map of the generation layer — how the per-subject generation docs (tile / nation / corporation / ledger) relate, and the home of the **economic premise**: a saturated, earth-like base whose broad industry the Nation AI owns, with the player and major AI as **specialist** space-interested corporations. Read first for questions spanning more than one generation doc, or about why corporations start lean. Cross-cutting open items (building tiers, allied-corp/franchise origin, post-WW2 grounding) live here.

**`docs/generation/TILE_GENERATION.md`**
The procedural tile generation strategy and six-pass pipeline used in `hard_coded_world.cpp`. Covers solar parameters (temperature class, atmosphere class, hydrological state, geological activity), prototype body profiles, the hybrid terrain / noise-banded ocean / cluster landform approach, and deposit generation rules. Read before any work on tile generation or the terrain enum expansion.

**`docs/generation/NATION_GENERATION.md`**
The procedural nation generation strategy: Voronoi BFS territory placement over the tile map, resource profile derivation, political character assignment, and naming. Nation system behaviour is an open item; this document covers generation only. Read before any work on the world political layer or campaign setup.

**`docs/generation/CORPORATION_GENERATION.md`**
The procedural corporation generation strategy: nation assignment, industrial focus, starting asset placement, and financial profile. Covers the player corporation marker, the deferred corporation selection screen, and open design items (franchising, nation-seeded privatisation, tax, Era-based sovereignty). Read before any work on faction setup or campaign initialisation.

**`docs/generation/GENERATION_LEDGER.md`**
The Generation Ledger (design only) — a tuning/analysis surface that explains *why* a tile generated as it did, reading the per-pass intermediates exposed by `generate_body_tiles`'s optional `generation_record`. Covers the per-tile derivation breadcrumb (height/ocean → band/moisture → composition → landform → deposits), per-body histograms, the regenerate-on-demand (don't-persist) data lifetime, and surfacing as a Ledger window plus a Planetary field-overlay lens. Read before building the generation ledger or any heightmap/moisture/band overlay.

---

## Delivery pipeline

The lifecycle for acting on a backlog **item**. **Full authority lives in
`docs/development/DELIVERY.md`**; this is the condensed reference.

### Rule 0 — size the effort to the job

Every non-trivial task states its **mode**:

- **Light (default).** A one-line fix, an obvious cleanup, a doc tweak — make it, check it, say
  what you did. No tasks, no requirements, no ceremony.
- **Full (earned).** Work whose coordination cost it repays — touches the economy / save-format /
  integration seam, spans more than ~2 files of real logic, or carries determinism risk. Run the
  Delivery lifecycle below.

**Rule 0a — ad-hoc ideas.** When the user raises an unscoped idea with no explicit "do it now",
offer two options **before acting**, without first asking clarifying questions: **A) save to the
backlog**, or **B) implement now** (smoke-test, then ask before committing).

### Source of truth — where each thing lives

| Concern | Authority | Notes |
|---|---|---|
| Backlog **metadata** (status, priority, sequencing, files) | `docs/development/backlog.json` | Queryable; the JSON wins over any prose/glyph. |
| Backlog **design prose** for an open item | `docs/development/backlog.json` (`design` field) | Design authority *while the item is open*; `BACKLOG.md` holds legacy bodies not yet migrated. |
| **Active worklist** (promoted tasks) | `docs/development/REFINED.md` | Transient; empty between work blocks. |
| **Method** (lifecycle, depth verbs, batch, worktrees) | `docs/development/DELIVERY.md` | The long-form of this section. |
| **Requirements** (data + history) | `req/requirements.json` (policy `req/REQUIREMENTS.md`) | |
| **Standing invariants** | `.claude/rules/io-standing-rules.md` | Always-on; the "do not" rules. |
| What was built / why | `docs/development/DEVLOG.md` | |

### The Delivery lifecycle (Full mode)

0. **Item-spanning requirement (gate — if the item changes `src/`).** Write one requirement
   covering the whole item in its `req/requirements.json` group (usually a `visual` check), first,
   so decomposition is shaped by it. Doc-only items exempt.
1. **Create tasks** — promote the item into `REFINED.md`: smallest independently-buildable steps
   (foundation first), each scoped to its files, dependencies marked.
2. **Create requirements** — append the item's requirement group to `req/requirements.json`.
3. **Plan parallelisation** — build the file **collision map**; it *informs how to split focused
   sub-agents* (see below), no longer gates them.
4. **Complete tasks** — implement, review, verify against requirements. Blocked/out-of-scope tasks
   are **cancelled** (intent returned to the backlog), not left in flight.
5. **Commit** — once all tasks are terminal, one commit per item:
   ```
   <item title>

   Tasks: <N completed>, <N cancelled>
   Requirements: <N completed>, <N pending>, <N failed>
   ```

**Batch Delivery** runs the steps as **barriers across the whole set** (breadth-first); step 4 is
the load-bearing barrier (all tasks terminal before any commit). It also runs the
**documentation-coverage discipline** (per-item doc collision map, transient `> ⟳` change notes, a
standing `S`-tier review item per changed doc, a closing design-direction Q&A when non-trivial
calls were made) and emits a **coarse `%` progress marker** between tool calls. **Timestamp every
new item**; newest-dated wins on conflict (a dated item outranks undated prose; no retroactive
refactor). Full detail in `DELIVERY.md`.

**Proportionality & pausing.** The lifecycle is proportional to the work (Rule 0); a Light change
skips steps 1–2. Pausing a group is a legitimate outcome — leave it clean and resumable rather
than forcing completion or cancelling.

### Sub-agents & worktrees (the parallelism model)

**Worktrees are the primary isolation mechanism.** Concurrent sub-agents each run in their own git
worktree (`isolation: "worktree"`), so two agents touching the same file no longer corrupt each
other. This **replaces** the old hard rule that sub-agents must have disjoint file write-sets.

- **The collision map is now a *splitting heuristic*, not a gate** — use it to carve **focused,
  meaningful agents** (each a coherent vertical slice), not to prove disjointness.
- **Keep each agent on a tight block of code, reading minimal documentation** — give it the task
  text, its files, and the one or two docs it actually needs, not the whole design corpus. A
  narrow, well-scoped agent is the unit that pays back.
- **Agents build and commit on their own worktree branch; the main session merges** them in
  dependency order, runs the integrating build, and verifies. Verify retroactively — assume
  nothing about an agent's self-reported success.
- **Hotspot/integration wiring stays in the main session.**
- **Fan-out is a discretionary call made *after* the tasks and collision map** — state the call
  and its reason rather than asking permission each time.

### Skills

These skills exist and should be used proactively rather than reinventing their steps:

- **`verifier-visual`** — runs the headless `ProjectIo --verify <script>` harness, inspects
  PNG captures, and reports against requirements. Authorising a new visual check means adding
  a `scripts/verify/<feature>.lua` and invoking this skill. Use for any `visual`-class
  requirement.
- **`verifier-headless`** — compiles and runs a `tools/verify/<name>.cpp` harness over the
  SDL/Lua-free `world/*` logic and reports its PASS/FAIL assertions. Use for any `headless`-class
  requirement (economy arithmetic, tile generation, placement audits). Authorising a new check
  means adding a `tools/verify/*.cpp` harness and naming it in the skill.
- **`verifier-review`** — static, no-compile review over an integrated diff; reports a verdict on
  cross-item symbol consistency, compile-by-inspection, standing invariants, the serialisation
  seam, and requirement coverage. The cheap pre-compile gate: run it in a Batch Delivery after
  slice merges and **before** the integrating build (DELIVERY.md step 4a). A filter, not a
  substitute — always still compile.
- **`scoped-commit`** — stages exactly the files belonging to the current task and commits
  with the correct format, without bundling unrelated working-tree changes. Use whenever
  committing, especially on the default branch or when the tree has pre-existing edits.

#### Tool creation is skill creation

When a check or automation does not yet have a tool, **author the tool, then push it to a
skill** — a skill is a permanent, reusable, discoverable asset; a loose tool or bespoke
procedure is forgotten. **Creating or modifying a skill requires user permission**, so the
workflow is:

1. **Attempt to author the tool** (a `tools/verify/*.cpp` harness, a `scripts/verify/*.lua`
   check, a script, or a documented procedure).
2. **Push it to a skill** — wrap the capability in a `.claude/skills/<name>/SKILL.md` (the
   `verifier-*` skills are the model), asking the user to authorise it.
3. **If skill creation is denied, request running the tool as a one-off** — execute it this
   session without promoting it, and note in the requirement's Notes that the method was run
   ad hoc rather than saved.

For a larger or speculative skill that needs design rather than a quick wrap, **propose it as
a backlog item** (category: Documentation or the relevant system category) instead of improvising.

#### settings.json permissions (slimmed model — confirmed 2026-06-16)

`.claude/settings.json` now uses **broad prefix allows + a `deny` safety net** rather than a
per-command mapping table. The allow-list covers routine read/build/git/worktree commands; the
`deny` list blocks the genuinely dangerous (`rm -rf`, `git push`, `git reset --hard`,
`git clean`) outright. This is the lighter model adopted from Project-Fulcrum's process, and the
allow/deny split is **confirmed**.

When in doubt, tighten an allow rule rather than broaden it. The per-harness exe allows (`econ_harness`, `world_audit`,
etc.) stay narrow because they are specific binaries; add a new harness's exe before it runs
prompt-free. `deny` takes precedence over `allow`, so a denied command is blocked even if an
allow rule would match.